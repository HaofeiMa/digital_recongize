#include <opencv2/opencv.hpp>
//#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include "myfunc.h"

using namespace cv;
using namespace std;

int main() {
	Mat src = imread("E:/Program/OpenCV/vcworkspaces/OGR/images/txt.jpg");	//��ȡͼƬ
	DigitalRec dr;

	//��ֵ������
	Mat grayImg = dr.binaryProc(src);

	//��ɫ��ת
	dr.colorReverse(grayImg);
	
	//�����и�
	Mat topImg, bottomImg;
	int rowFlag = dr.cutRows(grayImg, topImg, bottomImg);
	for (int i = 0; rowFlag == 0; i++) {
		Mat leftImg, rightImg;
		int colFlag = dr.cutCols(topImg, leftImg, rightImg);
		for (int j = 0; colFlag == 0; j++) {
			//imshow(to_string(i*10+j), leftImg);
			cout << dr.imgMatch(leftImg);
			//imwrite(to_string(i*10+j) + ".jpg", leftImg);
			Mat imageTemp = rightImg;
			colFlag = dr.cutCols(imageTemp, leftImg, rightImg);
		}
		Mat imageTemp = bottomImg;
		rowFlag = dr.cutRows(imageTemp, topImg, bottomImg);
	}
	


	waitKey(0);
	destroyAllWindows();;
	return 0;
}